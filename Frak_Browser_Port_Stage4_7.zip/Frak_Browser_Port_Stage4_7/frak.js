const FRAK_DATA = globalThis.FRAK_DATA;

// Frak! browser port - Stage 4.7 parity build.
// The JavaScript deliberately keeps the original routine/data model visible.
// Stage 4.3 retains the validated gameplay/audio path and tightens attract/title
// presentation against the original BBC output: panel geometry, score zero suppression,
// layering, and the final Trogg + FRAK! bubble composition.

const BBC_COLOURS = [
  '#000000', '#ff0000', '#00ff00', '#ffff00',
  '#0000ff', '#ff00ff', '#00ffff', '#ffffff'
];
const MODE1_WIDTH = 320;
const MODE1_HEIGHT = 256;
const MODE1_X_SCALE = 4;     // one Frak logical X = one MODE 1 byte = 4 pixels
const OBJECT_EMPTY = 0xff;

const COLLIDE_PLAYER_HAZARD = 0x01;
const COLLIDE_FLOOR = 0x02;
const COLLIDE_LADDER = 0x04;
const COLLIDE_YOYO = 0x08;
const COLLIDE_COLLECTIBLE = 0x10;
const COLLIDE_RESERVED_40 = 0x40;
const COLLIDE_YOYO_DARK = 0x80;

const QUEUES = {
  T: { first: 0,  end: 3,   name: 'Trogg',        mask: 0x00 },
  D: { first: 3,  end: 13,  name: 'Daggers',      mask: COLLIDE_PLAYER_HAZARD | COLLIDE_YOYO },
  B: { first: 13, end: 23,  name: 'Balloons',     mask: COLLIDE_PLAYER_HAZARD | COLLIDE_YOYO },
  K: { first: 23, end: 38,  name: 'Collectibles', mask: COLLIDE_COLLECTIBLE | COLLIDE_RESERVED_40 },
  M: { first: 38, end: 48,  name: 'Monsters',      mask: COLLIDE_PLAYER_HAZARD | COLLIDE_YOYO | COLLIDE_YOYO_DARK | COLLIDE_RESERVED_40 },
  F: { first: 48, end: 93,  name: 'Floors',        mask: COLLIDE_FLOOR },
  L: { first: 93, end: 123, name: 'Ladders',       mask: COLLIDE_LADDER },
};

const TROGG_SLOT = 0;
const PLAYER_UPDATE_DIVISOR = FRAK_DATA.constants.PLAYER_UPDATE_DIVISOR ?? 4;
const COUNTDOWN_TICKS_PER_SEC = FRAK_DATA.constants.COUNTDOWN_TICKS_PER_SEC ?? 50;
const VERTICAL_INPUT_STEP = 3;
const PLAYER_INITIAL_JUMP_DY = 5;
const PLAYER_Y_CEILING = 0xde;
const PLAYER_MAX_SAFE_FALL_DY = -7;
const PLAYER_X_MIN = 0x04;
const PLAYER_X_MAX_EXCLUSIVE = 0xc4;
const SCROLL_LEFT_TRIGGER_MIN = 0x28;
const SCROLL_LEFT_TRIGGER_MAX = 0x9f;
const SCROLL_RIGHT_TRIGGER_MIN = 0x29;
const SCROLL_RIGHT_TRIGGER_MAX = 0xa0;
const LADDER_PROBE_BOTTOM_OFFSET = 0x0e;
const LADDER_PROBE_HEIGHT = 0x1e;
const PLAYER_LANDING_Y_ADJUST = 5;
const PLAYER_FLOOR_PROBE_DY_LIMIT = -10;
const PLAYER_DEATH_DELAY_TICKS = 0x82;
const HAZARD_RANDOM_MAX = 3;
const HAZARD_BASE_RELOAD = FRAK_DATA.constants.HAZARD_BASE_RELOAD ?? 0x0b;
const HAZARD_EXPIRED_REDUCTION = 0x0a;
const SCREEN_COMPLETE_FRAMES = 0x3c;
const TRANSITION_FRAME_DELAY = 4;
const TIME_BONUS_REPEAT_COUNT = 0x0a;
const BCD_SECONDS_PER_MINUTE = 0x60;
const TRANSITION_TROGG_FRAMES = [0x35, 0x36, 0x37, 0x34];
const DYNAMIC_SPAWN_DELAY = 0x14;
const BALLOON_Y_STEP = 0x06;
const BALLOON_DESPAWN_Y = 0xf0;
const DAGGER_Y_STEP = 0x02;
const DAGGER_MIN_Y = 0x14;
const BALLOON_SPAWN_Y = 0x08;
const DAGGER_SPAWN_Y = 0xfa;
const DAGGER_SPAWN_X_SPAN = 0x28;
const DAGGER_SPAWN_X_OFFSET = 0x32;
const BALLOON_SPAWN_X_SPAN = 0x50;
const PRNG_INCREMENT = FRAK_DATA.constants.PRNG_INCREMENT ?? 0x63;
const PRNG_TOP_BIT = FRAK_DATA.constants.PRNG_TOP_BIT ?? 0x80;
const TITLE_TIMEOUT_TICKS = FRAK_DATA.title?.timeoutTicks ?? (7 * 256);
const TITLE_RANDOM_DRAW_COUNT = FRAK_DATA.title?.randomDrawCount ?? 0x7d;
const TITLE_SCORE_HOLD_TICKS = (31 * 4 * 2) + 0x4b + 0xfa;
const MUSIC_IRQ_HZ = 40;
const MUSIC_PHASE_STEP = 4;       // 50 Hz game tick -> 40 Hz music IRQ: +4 / threshold 5
const MUSIC_PHASE_LIMIT = 5;
const HIGH_SCORE_COUNT = 6;
const HIGH_SCORE_RECORD_SIZE = 6;
const HIGH_SCORE_INITIALS = 3;
const TITLE_TRANSITION_FRAMES = FRAK_DATA.title?.transitionFrames ?? 0x1f;
const TITLE_TRANSITION_FRAME_DELAY = FRAK_DATA.title?.transitionFrameDelay ?? 4;
const TITLE_TRANSITION_Y = FRAK_DATA.title?.transitionY ?? 0x52;
const TITLE_TRANSITION_DELAY = FRAK_DATA.title?.transitionDelay ?? 0x4b;
const TITLE_FINAL_WAIT = FRAK_DATA.title?.finalWait ?? 0xfa;
const TITLE_FINAL_Y = FRAK_DATA.title?.finalY ?? 0x52;
const TITLE_CLIP_LEFT = FRAK_DATA.title?.clipLeft ?? 0x0c;
const TITLE_CLIP_RIGHT = FRAK_DATA.title?.clipRight ?? 0x44;

const SPRITE_TROGG_CLIMB_A = 0x13;
const SPRITE_TROGG_CLIMB_B = 0x14;
const SPRITE_TROGG_YOYO_RIGHT = 0x3c;
const SPRITE_TROGG_YOYO_LEFT = 0x3d;
const YOYO_HEAD_SPRITES = [0x0e, 0x0d, 0x0f, 0x10];
const YOYO_STRING_SPRITES = [0xff, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33];
const YOYO_STRING_SLOT = 1;
const YOYO_HEAD_SLOT = 2;
const YOYO_HEAD_X_OFFSET = 2;
const YOYO_VERTICAL_OFFSET = 0x0b;
const YOYO_MIN_EXTENSION = 0x05;
const YOYO_MAX_EXTENSION = 0x0b;
const YOYO_RIGHT_LIMIT = 0xc8;
const YOYO_KNOCKBACK_FRAMES = 5;
const YOYO_KNOCKBACK_STEPS = 8;
const SCORE_MONSTER_BCD = 0x25;
const SPRITE_TROGG_FRAME0 = FRAK_DATA.constants.SPRITE_TROGG_FRAME0;
const SPRITE_TROGG_FRAME1 = FRAK_DATA.constants.SPRITE_TROGG_FRAME1;
const SPRITE_TROGG_FRAME2 = FRAK_DATA.constants.SPRITE_TROGG_FRAME2;
const SPRITE_TROGG_FRAME3 = FRAK_DATA.constants.SPRITE_TROGG_FRAME3;
const SPRITE_TROGG_FRAME4 = FRAK_DATA.constants.SPRITE_TROGG_FRAME4;
const SPRITE_TROGG_FRAME5 = FRAK_DATA.constants.SPRITE_TROGG_FRAME5;
const SPRITE_TROGG_FRAME6 = FRAK_DATA.constants.SPRITE_TROGG_FRAME6;
const SPRITE_TROGG_FRAME7 = FRAK_DATA.constants.SPRITE_TROGG_FRAME7;
const PLAYER_WALK_FRAMES_RIGHT = [SPRITE_TROGG_FRAME0, SPRITE_TROGG_FRAME1, SPRITE_TROGG_FRAME2, SPRITE_TROGG_FRAME3];
const PLAYER_WALK_FRAMES_LEFT  = [SPRITE_TROGG_FRAME7, SPRITE_TROGG_FRAME6, SPRITE_TROGG_FRAME5, SPRITE_TROGG_FRAME4];

const state = {
  objectX: new Uint8Array(123),
  objectY: new Uint8Array(123),
  objectSprite: new Uint8Array(123),
  objectDX: new Uint8Array(23),
  objectDY: new Uint8Array(23),
  lives: FRAK_DATA.constants.INITIAL_LIVES ?? 3,
  baseScreen: 0,
  transformCycle: 0,
  scoreLo: 0,
  scoreMid: 0,
  scoreHi: 0,
  timeLoBCD: 0,
  timeHiBCD: 2,
  countdownDivider: COUNTDOWN_TICKS_PER_SEC,
  viewportXOffset: 0,
  tickCounter: 0,
  lastPlayerUpdateTick: 0,
  selectedLevel: 'A',
  theme: 'C',
  levelError: '',
  running: true,
  playerAirborne: false,
  playerClimbing: false,
  yoyoActive: false,
  yoyoBaseX: 0,
  yoyoExtensionDirection: 1,
  yoyoSegmentPhase: 0,
  yoyoExtensionCount: 0xff,
  yoyoAnimationIndex: 0xff,
  yoyoKnockbackTicks: 0,
  yoyoHitSlot: -1,
  playerHorizontalStep: 1,
  playerFrameSprite: SPRITE_TROGG_FRAME0,
  walkAnimationPhase: 0,
  jumpInputHistory: 0,
  inputLatchUp: false,
  inputLatchDown: false,
  playerDead: false,
  deathTicksRemaining: 0,
  keysRemainingMinusOne: 0,
  collidedObjectSlot: -1,
  collidedQueueTag: '',
  supportObjectSlot: -1,
  hazardCounter: 1,
  hazardReload: HAZARD_BASE_RELOAD * 4,
  randomState: 0x30,
  screenCompletePending: false,
  completionFramesRemaining: 0,
  completionTickDivider: 0,
  completionFramePhase: 0,
  countdownExpired: false,
  mode: 'titleCast',
  titleTicksRemaining: TITLE_TIMEOUT_TICKS,
  titleRandomDrawCount: 0,
  titleRandomSprite: FRAK_DATA.title?.randomSprites?.[0] ?? 0x22,
  titleFrameDirty: true,
  titleTransitionFramesRemaining: 0,
  titleTransitionTickDivider: 0,
  titleTransitionSlot: 0,
  titlePostDelay: 0,
  titleFinalWait: 0,
  soundMuted: false,
  musicInhibit: true,
  currentTune: null,
  tunePosition: 0,
  musicDurationCounter: 0,
  musicTickPhase: 0,
  paused: false,
  highScores: Uint8Array.from(FRAK_DATA.highScores ?? []),
  highScoreRank: -1,
  highScoreInitialIndex: 0,
  highScoreEntryChar: 0x41,
};

state.objectSprite.fill(OBJECT_EMPTY);

const canvas = document.getElementById('screen');
const ctx = canvas.getContext('2d', { alpha: false });
ctx.imageSmoothingEnabled = false;
const frame = ctx.createImageData(MODE1_WIDTH, MODE1_HEIGHT);
const framePixels = frame.data;
let logicalPalette = [6, 5, 3, 0];
let logicalClipLeft = 0;
let logicalClipRight = 0x50;
let lastFrameTime = performance.now();
let accumulator = 0;
const TICK_MS = 1000 / 50;
const pressed = new Set();

function u8(v) { return v & 0xff; }
function signed8(v) { v &= 0xff; return v < 0x80 ? v : v - 0x100; }
function sign(v) { return v === 0 ? 0 : (v < 0 ? -1 : 1); }

// ---------------------------------------------------------------------------
// Original object/game lifecycle
// ---------------------------------------------------------------------------

// 6502: ClearObjectTables
function clearObjectTables() {
  state.objectX.fill(0);
  state.objectY.fill(0);
  state.objectSprite.fill(OBJECT_EMPTY);
  state.objectDX.fill(0);
  // Original ClearObjectTables writes &FF into the 23 ObjectDY entries.
  state.objectDY.fill(OBJECT_EMPTY);
}

// 6502: NewGame
function newGame() {
  ensureAudio();
  state.mode = 'playing'; state.running = true; state.paused = false;
  state.lives = FRAK_DATA.constants.INITIAL_LIVES ?? 3;
  state.baseScreen = 0;
  state.transformCycle = 0;
  state.scoreLo = 0;
  state.scoreMid = 0;
  state.scoreHi = 0;
  startScreen('A');
}

// 6502: DisplayInit / ApplyDisplayTransform
function applyDisplayTransform() {
  const t = state.transformCycle & 7;
  const baseColour = FRAK_DATA.screenColours[state.baseScreen] ?? 6;
  state.viewportXOffset = 0;
  logicalClipLeft = 0; logicalClipRight = 0x50;
  if ((t & 0x04) !== 0) {
    if ((t & 0x02) === 0) logicalPalette = [0, 5, 3, 0];
    else logicalPalette = [0, 0, 0, 7];
  } else if ((t & 0x02) !== 0) {
    logicalPalette = [7, 7, 7, 0];
  } else {
    logicalPalette = [baseColour, 5, 3, 0];
  }
}

// 6502: StartScreen
function startScreen(levelLetter = ['A', 'B', 'C'][state.baseScreen]) {
  state.mode = 'playing'; state.running = true;
  const idx = Math.max(0, ['A', 'B', 'C'].indexOf(levelLetter));
  state.baseScreen = idx;
  state.selectedLevel = ['A', 'B', 'C'][idx];
  state.timeHiBCD = FRAK_DATA.initialMinutesBCD[idx];
  state.timeLoBCD = 0;
  selectTune(['screenA','screenB','screenC'][idx]);
  state.countdownDivider = COUNTDOWN_TICKS_PER_SEC;
  state.levelError = '';
  state.walkAnimationPhase = 0;
  state.playerDead = false;
  state.deathTicksRemaining = 0;
  state.yoyoActive = false;
  state.yoyoBaseX = 0;
  state.yoyoExtensionDirection = 1;
  state.yoyoSegmentPhase = 0;
  state.yoyoExtensionCount = 0xff;
  state.yoyoAnimationIndex = 0xff;
  state.yoyoKnockbackTicks = 0;
  state.yoyoHitSlot = -1;
  state.playerClimbing = false;
  state.playerAirborne = false;
  state.playerHorizontalStep = 1;
  state.jumpInputHistory = 0;
  state.inputLatchUp = false;
  state.inputLatchDown = false;
  state.screenCompletePending = false;
  state.completionFramesRemaining = 0;
  state.completionTickDivider = 0;
  state.completionFramePhase = 0;
  state.countdownExpired = false;
  state.hazardReload = u8((HAZARD_BASE_RELOAD - (state.transformCycle & 7)) * 4);
  state.hazardCounter = 1;
  state.lastPlayerUpdateTick = state.tickCounter;
  clearObjectTables();
  applyDisplayTransform();
  loadLevelStream(state.selectedLevel);
  state.keysRemainingMinusOne = u8(countSpriteInQueue('K', FRAK_DATA.constants.SPRITE_KEY) - 1);
  renderFrame();
  updateInfo();
}

// 6502: LoadLevelStream (&17B8)
function loadLevelStream(levelLetter) {
  const bytes = FRAK_DATA.levels[levelLetter];
  if (!bytes) throw new Error(`Unknown level ${levelLetter}`);
  let p = 0;
  state.theme = String.fromCharCode(bytes[p++]);
  const themeMap = FRAK_DATA.themeMaps[state.theme];
  if (!themeMap) throw new Error(`Unknown Frak theme ${state.theme}`);

  while (p < bytes.length) {
    const tagByte = bytes[p++];
    if (tagByte === 0xff) return;
    const tag = String.fromCharCode(tagByte);
    const queue = QUEUES[tag];
    const variants = themeMap[tag];
    if (!queue || !variants) throw new Error(`Level references unsupported queue ${tag}`);
    let slot = queue.first;
    while (p < bytes.length) {
      const record = bytes[p++];
      const count = record >>> 3;
      if (count === 0) break;
      const variant = record & 7;
      const sprite = variants[variant];
      if (sprite === undefined) throw new Error(`Theme ${state.theme}/${tag} variant ${variant} has no sprite`);
      for (let i = 0; i < count; i++) {
        while (slot < queue.end && state.objectSprite[slot] !== OBJECT_EMPTY) slot++;
        if (slot >= queue.end) throw new Error(`Queue ${tag} overflow while decoding level`);
        state.objectX[slot] = bytes[p++];
        state.objectY[slot] = bytes[p++];
        state.objectSprite[slot] = sprite;
        slot++;
      }
    }
  }
  throw new Error('Level stream ended without FF terminator');
}

function countObjectsOfType(tag) {
  const q = QUEUES[tag];
  if (!q) return 0;
  let n = 0;
  for (let i = q.first; i < q.end; i++) if (state.objectSprite[i] !== OBJECT_EMPTY) n++;
  return n;
}

function countSpriteInQueue(tag, sprite) {
  const q = QUEUES[tag];
  let n = 0;
  for (let i = q.first; i < q.end; i++) if (state.objectSprite[i] === sprite) n++;
  return n;
}

function findFreeSlot(tag) {
  const q = QUEUES[tag];
  for (let i = q.first; i < q.end; i++) if (state.objectSprite[i] === OBJECT_EMPTY) return i;
  return -1;
}

// 6502: AddScoreBCD (&15B8)
function addScoreBCD(packedBcd) {
  const bcdAdd = (a, b, carry = 0) => {
    let lo = (a & 15) + (b & 15) + carry;
    carry = lo > 9 ? 1 : 0;
    if (carry) lo -= 10;
    let hi = (a >>> 4) + (b >>> 4) + carry;
    carry = hi > 9 ? 1 : 0;
    if (carry) hi -= 10;
    return [((hi << 4) | lo) & 255, carry];
  };
  const previousMid = state.scoreMid;
  let carry;
  [state.scoreLo, carry] = bcdAdd(state.scoreLo, packedBcd, 0);
  [state.scoreMid, carry] = bcdAdd(state.scoreMid, 0, carry);
  [state.scoreHi] = bcdAdd(state.scoreHi, 0, carry);
  if (((previousMid ^ state.scoreMid) & 0x20) !== 0) state.lives++;
}

function addBcdSeconds(amountBcd) {
  let units = (state.timeLoBCD & 0x0f) + (amountBcd & 0x0f);
  let tens = ((state.timeLoBCD >> 4) & 0x0f) + ((amountBcd >> 4) & 0x0f);
  if (units > 9) { units -= 10; tens++; }
  let seconds = tens * 10 + units;
  while (seconds >= 60) { seconds -= 60; state.timeHiBCD = u8(state.timeHiBCD + 1); }
  state.timeLoBCD = ((Math.floor(seconds / 10) << 4) | (seconds % 10)) & 0xff;
}

// ---------------------------------------------------------------------------
// Sprite descriptor / MODE 1 renderer
// ---------------------------------------------------------------------------

function spriteDescriptor(sprite) {
  const t = FRAK_DATA.spriteTables;
  return {
    xOffset: signed8(t.SpriteXOffsets[sprite]),
    yOffset: signed8(t.SpriteYOffsets[sprite]),
    defLo: t.SpriteDefLo[sprite],
    defHi: t.SpriteDefHi[sprite],
    widthFlags: t.SpriteWidthFlags[sprite],
    heightCount: t.SpriteHeightCount[sprite],
  };
}

function mode1Pixels(byte) {
  return [0, 1, 2, 3].map(i => ((((byte >> (7 - i)) & 1) << 1) | ((byte >> (3 - i)) & 1)));
}

function putLogicalPixel(x, y, logical, transparentZero = false) {
  if (transparentZero && logical === 0) return;
  if (x < 0 || x >= MODE1_WIDTH || y < 0 || y >= MODE1_HEIGHT) return;
  const physical = logicalPalette[logical & 3] & 7;
  const rgb = hexToRgb(BBC_COLOURS[physical]);
  const o = (y * MODE1_WIDTH + x) * 4;
  framePixels[o] = rgb[0]; framePixels[o + 1] = rgb[1]; framePixels[o + 2] = rgb[2]; framePixels[o + 3] = 255;
}

const rgbCache = new Map();
function hexToRgb(hex) {
  if (rgbCache.has(hex)) return rgbCache.get(hex);
  const n = parseInt(hex.slice(1), 16);
  const v = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  rgbCache.set(hex, v); return v;
}

function clearFrame() {
  const rgb = hexToRgb(BBC_COLOURS[logicalPalette[0]]);
  for (let i = 0; i < framePixels.length; i += 4) {
    framePixels[i] = rgb[0]; framePixels[i + 1] = rgb[1]; framePixels[i + 2] = rgb[2]; framePixels[i + 3] = 255;
  }
}

// ---------------------------------------------------------------------------
// BBC SOUND/ENVELOPE host — Stage 4 fidelity pass.
//
// Frak only uses MOS tone channels 1..3, never the noise channel.  The browser
// therefore does not need a whole BBC emulator here: it retains the original
// OSWORD 7 blocks and OSWORD 8 envelope records, runs the relevant MOS envelope
// state machine at 100 Hz, converts BBC quarter-semitone pitch bytes through the
// MOS 1.20 lookup tables, and drives square-wave voices with SN76489-style 2 dB
// attenuation steps.  This keeps the Frak-facing behaviour close to the BBC
// without coupling the port to an emulator.
// ---------------------------------------------------------------------------
const MOS_ENVELOPE_HZ = 100;
const MOS_VOLUME_SILENT = 0xC7;
const MOS_VOLUME_LOUDEST = 0x3F;
const MOS_VOLUME_CLAMP_SILENT = 0xC0;
const MOS_RELEASE_COMPLETE = 4;
const MOS_PITCH_SECTION_COMPLETE = 3;
const MOS_NO_ENVELOPE = 0xFF;
const SN_CLOCK_DIV16_HZ = 250000;
const SN_SQUARE_BASE_HZ = SN_CLOCK_DIV16_HZ / 2;
const BBC_PITCH_LOOKUP_LOW  = [0xF0,0xB7,0x82,0x4F,0x20,0xF3,0xC8,0xA0,0x7B,0x57,0x35,0x16];
const BBC_PITCH_LOOKUP_HIGH = [0xE7,0xD7,0xCB,0xC3,0xB7,0xAA,0xA2,0x9A,0x92,0x8A,0x82,0x7A];
const BBC_CHANNEL_PITCH_OFFSET = [0,0,1,2];
const SN_VOLUME_TABLE = (() => {
  const out = new Float32Array(16);
  let f = 1;
  for (let i=0;i<15;i++) { out[i]=f; f *= Math.pow(10,-0.1); }
  out[15]=0;
  return out;
})();

let audioContext = null;
let masterGain = null;
const activeAudioChannels = new Map(); // MOS channel -> voice state

function ensureAudio() {
  const AC = globalThis.AudioContext || globalThis.webkitAudioContext;
  if (!AC) return null;
  if (!audioContext) {
    audioContext = new AC();
    masterGain = audioContext.createGain();
    masterGain.gain.value = state.soundMuted ? 0 : 0.14;
    masterGain.connect(audioContext.destination);
  }
  if (audioContext.state === 'suspended') audioContext.resume?.();
  return audioContext;
}

// MOS 1.20 pitch-byte -> SN76489 10-bit tone period.  Frak's MUSIC bytes and
// PlayerMovePitch are BBC pitch values, not linear frequencies.
function bbcPitchPeriod(pitch, mosChannel = 3) {
  pitch = u8(pitch);
  const fractional = pitch & 3;
  let semitone = pitch >>> 2;
  let octave = 0;
  while (semitone >= 12) { octave++; semitone -= 12; }
  let lo = BBC_PITCH_LOOKUP_LOW[semitone];
  let hi = BBC_PITCH_LOOKUP_HIGH[semitone] & 3;
  const fractionalStep = BBC_PITCH_LOOKUP_HIGH[semitone] >>> 4;
  for (let i=0;i<fractional;i++) {
    lo -= fractionalStep;
    if (lo < 0) { lo += 256; hi--; if (hi < 0) hi += 4; }
  }
  let period = (((hi & 3) << 8) | (lo & 0xff)) >>> octave;
  period += BBC_CHANNEL_PITCH_OFFSET[mosChannel & 3] ?? 0;
  return period & 0x3ff;
}
function bbcPitchHz(pitch, mosChannel = 3) {
  const period = bbcPitchPeriod(pitch, mosChannel) || 1024;
  return SN_SQUARE_BASE_HZ / period;
}

function internalVolumeToSnAttenuation(volume) {
  return (((((u8(volume) - 0x40) & 0xff) >>> 3) ^ 0x0f) & 0x0f);
}
function voiceGainValue(voice) {
  return SN_VOLUME_TABLE[internalVolumeToSnAttenuation(voice.volume)];
}
function updateVoiceAudio(voice) {
  if (!voice) return;
  const ac = audioContext;
  if (voice.oscillator && ac) {
    voice.oscillator.frequency.setValueAtTime(bbcPitchHz(voice.actualPitch, voice.channel), ac.currentTime);
  }
  if (voice.gain && ac) {
    voice.gain.gain.setValueAtTime(voiceGainValue(voice), ac.currentTime);
  }
}
function createVoiceAudio(voice) {
  const ac = ensureAudio();
  if (!ac || !masterGain) return;
  const osc = ac.createOscillator();
  const gain = ac.createGain();
  osc.type = 'square';
  gain.gain.value = 0;
  osc.connect(gain); gain.connect(masterGain);
  voice.oscillator = osc; voice.gain = gain;
  updateVoiceAudio(voice);
  osc.start();
}
function stopAudioChannel(channel) {
  const key = channel & 3;
  const old = activeAudioChannels.get(key);
  if (!old) return;
  try { old.oscillator?.stop(); } catch (_) {}
  activeAudioChannels.delete(key);
}
function stopAllAudio() {
  for (const key of [...activeAudioChannels.keys()]) stopAudioChannel(key);
}

function envelopeForBlock(block, name) {
  // Data is keyed by semantic block name, but the envelope number is retained
  // in the block and checked so edits to Frak's source cannot silently mismatch.
  const env = FRAK_DATA.envelopes?.[name] || FRAK_DATA.envelopes?.music;
  if (!env || env[0] !== block.envelope) return env;
  return env;
}

// Frak's four blocks all set channel bit 4 (flush), so there is no queued SOUND
// buffer to reproduce for this program: each call replaces the current voice on
// that MOS channel immediately, exactly the path Frak exercises.
function playSoundBlock(name, pitchOverride = null) {
  const block = FRAK_DATA.soundBlocks?.[name];
  if (!block) return;
  const channel = block.channel & 3;
  if ((block.channel & 0x10) !== 0) stopAudioChannel(channel);
  const env = envelopeForBlock(block, name);
  const basePitch = u8(pitchOverride == null ? block.pitch : pitchOverride);
  const voice = {
    name, channel, env,
    basePitch, actualPitch: basePitch, pitchOffset: 0,
    section: MOS_NO_ENVELOPE, sectionCountdown: 0,
    phase: 0, stepCountdown: 1,
    volume: MOS_VOLUME_SILENT,
    duration: block.duration ?? 0xff,
    durationCountdown100Hz: 5,
    oscillator: null, gain: null,
  };
  activeAudioChannels.set(channel, voice);
  createVoiceAudio(voice);
  return voice;
}

function applyEnvelopeAmplitude(voice) {
  if (!voice.env || voice.phase >= MOS_RELEASE_COMPLETE) return;
  const env = voice.env;
  const targetRaw = voice.phase < 2 ? env[12 + voice.phase] : 0;
  const targetAmplitude = (targetRaw - MOS_VOLUME_LOUDEST) & 0xff;
  const step = env[8 + voice.phase] & 0xff;
  const old = voice.volume;
  let next = (old + step) & 0xff;
  const overflow = (((old ^ next) & (step ^ next) & 0x80) !== 0);
  if (overflow) next = (next & 0x80) ? MOS_VOLUME_LOUDEST : MOS_VOLUME_CLAMP_SILENT;
  if (((next >>> 6) & 1) !== ((next >>> 7) & 1)) {
    next = (next & 0x80) ? MOS_VOLUME_CLAMP_SILENT : MOS_VOLUME_LOUDEST;
  }
  voice.volume = next;
  const distance = (voice.volume - targetAmplitude) & 0xff;
  const stepMinus1 = (step - 1) & 0xff;
  if (((distance ^ stepMinus1) & 0x80) === 0) {
    voice.volume = targetAmplitude;
    voice.phase++;
  }
}
function applyEnvelopePitch(voice) {
  const env = voice.env;
  if (!env || voice.section === MOS_PITCH_SECTION_COMPLETE) return;
  const applyStep = () => {
    const delta = signed8(env[2 + voice.section]);
    voice.pitchOffset = u8(voice.pitchOffset + delta);
    voice.actualPitch = u8(voice.basePitch + voice.pitchOffset);
  };
  if (voice.sectionCountdown !== 0) {
    voice.sectionCountdown--;
    applyStep();
    return;
  }
  voice.section = u8(voice.section + 1);
  if (voice.section === MOS_PITCH_SECTION_COMPLETE) {
    // T bit 7 clear means auto-repeat the three pitch sections.
    if ((env[1] & 0x80) === 0) { voice.section = 0; voice.pitchOffset = 0; }
    else return;
  }
  voice.sectionCountdown = env[5 + voice.section] & 0xff;
  if (voice.sectionCountdown === 0) return;
  voice.sectionCountdown--;
  applyStep();
}
function mosEnvelopeTick() {
  for (const [channel, voice] of [...activeAudioChannels.entries()]) {
    // SOUND duration 255 is infinite in the MOS path.  Frak uses 255 in all
    // four live blocks; this finite-duration path is retained for completeness.
    if (voice.duration !== 0xff && voice.duration > 0) {
      if (--voice.durationCountdown100Hz <= 0) {
        voice.durationCountdown100Hz = 5; // 20 Hz duration units
        voice.duration--;
        if (voice.duration === 0 && voice.phase < 3) voice.phase = 3;
      }
    }
    if (voice.stepCountdown !== 0) {
      voice.stepCountdown--;
      if (voice.stepCountdown !== 0) { updateVoiceAudio(voice); continue; }
    }
    voice.stepCountdown = Math.max(1, (voice.env?.[1] ?? 1) & 0x7f);
    applyEnvelopeAmplitude(voice);
    applyEnvelopePitch(voice);
    updateVoiceAudio(voice);
    if (voice.phase >= MOS_RELEASE_COMPLETE && voiceGainValue(voice) === 0 && voice.duration !== 0xff) {
      stopAudioChannel(channel);
    }
  }
}
function audioDebugState() {
  return [...activeAudioChannels.values()].map(v => ({
    name:v.name, channel:v.channel, basePitch:v.basePitch, actualPitch:v.actualPitch,
    period:bbcPitchPeriod(v.actualPitch,v.channel), volume:v.volume,
    attenuation:internalVolumeToSnAttenuation(v.volume), phase:v.phase, section:v.section
  }));
}
function setSoundMuted(muted) {
  state.soundMuted = !!muted;
  if (masterGain && audioContext) masterGain.gain.setValueAtTime(state.soundMuted ? 0 : 0.14, audioContext.currentTime);
  updateInfo();
}

// 6502: SelectTune (&18B4)
function selectTune(name) {
  if (!FRAK_DATA.soundStreams?.[name]) return;
  state.currentTune = name;
  state.tunePosition = 0;
  state.musicDurationCounter = 0;
  state.musicInhibit = false;
}
// 6502: MusicStep (&186B)
function musicStep() {
  if (state.musicInhibit || state.paused || !state.currentTune) return;
  const stream = FRAK_DATA.soundStreams[state.currentTune];
  if (!stream?.length) return;
  const b = stream[state.tunePosition++] ?? stream[0];
  const terminator = (b & 0x80) !== 0;
  const pitch = b & 0x7c;
  const units = ((b & 3) + 1) * 4;
  state.musicDurationCounter = units - 1;
  playSoundBlock('music', pitch);
  if (terminator) {
    state.tunePosition = 0;
    if (state.currentTune === 'death' || state.currentTune === 'complete') state.musicInhibit = true;
  }
}
// 6502: SoundIRQ Timer-1 music path.
function soundIRQ() {
  if (state.musicInhibit || state.paused) return;
  state.musicDurationCounter--;
  if (state.musicDurationCounter < 0) musicStep();
}

// BBC MOS 8x8 system font, ASCII 32..127. Each glyph is eight rows;
// bit 7 = leftmost pixel. Text is plotted directly into the 320x256 framebuffer
// so browser font selection, hinting and antialiasing cannot alter the BBC image.
const BBC_MOS_FONT_8X8 = new Uint8Array([
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00, //  32 ' '
  0x18,0x18,0x18,0x18,0x18,0x00,0x18,0x00, //  33 '!'
  0x6C,0x6C,0x6C,0x00,0x00,0x00,0x00,0x00, //  34 '"'
  0x6C,0x6C,0xFE,0x6C,0xFE,0x6C,0x6C,0x00, //  35 '#'
  0x10,0x7E,0xD0,0x7C,0x16,0xFC,0x10,0x00, //  36 '$'
  0x46,0xAC,0x58,0x30,0x64,0xCA,0x84,0x00, //  37 '%'
  0x38,0x6C,0x38,0x76,0xDC,0xCC,0x76,0x00, //  38 '&'
  0x18,0x18,0x30,0x00,0x00,0x00,0x00,0x00, //  39 "'"
  0x18,0x30,0x30,0x30,0x30,0x30,0x18,0x00, //  40 '('
  0x30,0x18,0x18,0x18,0x18,0x18,0x30,0x00, //  41 ')'
  0x00,0x18,0x7E,0x3C,0x7E,0x18,0x00,0x00, //  42 '*'
  0x00,0x18,0x18,0x7E,0x18,0x18,0x00,0x00, //  43 '+'
  0x00,0x00,0x00,0x00,0x00,0x18,0x18,0x30, //  44 ','
  0x00,0x00,0x00,0x7C,0x00,0x00,0x00,0x00, //  45 '-'
  0x00,0x00,0x00,0x00,0x00,0x30,0x30,0x00, //  46 '.'
  0x02,0x06,0x0C,0x18,0x30,0x60,0xC0,0x00, //  47 '/'
  0x3C,0x66,0x6E,0x7E,0x76,0x66,0x3C,0x00, //  48 '0'
  0x18,0x38,0x18,0x18,0x18,0x18,0x7E,0x00, //  49 '1'
  0x3C,0x66,0x06,0x0C,0x18,0x30,0x7E,0x00, //  50 '2'
  0x3C,0x66,0x06,0x1C,0x06,0x66,0x3C,0x00, //  51 '3'
  0x0C,0x1C,0x3C,0x6C,0x7E,0x0C,0x0C,0x00, //  52 '4'
  0x7E,0x60,0x7C,0x06,0x06,0x66,0x3C,0x00, //  53 '5'
  0x1C,0x30,0x60,0x7C,0x66,0x66,0x3C,0x00, //  54 '6'
  0x7E,0x06,0x0C,0x18,0x30,0x30,0x30,0x00, //  55 '7'
  0x3C,0x66,0x66,0x3C,0x66,0x66,0x3C,0x00, //  56 '8'
  0x3C,0x66,0x66,0x3E,0x06,0x0C,0x38,0x00, //  57 '9'
  0x00,0x00,0x18,0x18,0x00,0x18,0x18,0x00, //  58 ':'
  0x00,0x00,0x18,0x18,0x00,0x18,0x18,0x30, //  59 ';'
  0x0C,0x18,0x30,0x60,0x30,0x18,0x0C,0x00, //  60 '<'
  0x00,0x00,0x7C,0x00,0x7C,0x00,0x00,0x00, //  61 '='
  0x60,0x30,0x18,0x0C,0x18,0x30,0x60,0x00, //  62 '>'
  0x3C,0x66,0x0C,0x18,0x18,0x00,0x18,0x00, //  63 '?'
  0x3C,0x42,0x9A,0xAA,0x9C,0x40,0x3C,0x00, //  64 '@'
  0x3C,0x66,0x66,0x7E,0x66,0x66,0x66,0x00, //  65 'A'
  0x7C,0x66,0x66,0x7C,0x66,0x66,0x7C,0x00, //  66 'B'
  0x3C,0x66,0x60,0x60,0x60,0x66,0x3C,0x00, //  67 'C'
  0x78,0x6C,0x66,0x66,0x66,0x6C,0x78,0x00, //  68 'D'
  0x7E,0x60,0x60,0x7C,0x60,0x60,0x7E,0x00, //  69 'E'
  0x7E,0x60,0x60,0x7C,0x60,0x60,0x60,0x00, //  70 'F'
  0x3C,0x66,0x60,0x6E,0x66,0x66,0x3C,0x00, //  71 'G'
  0x66,0x66,0x66,0x7E,0x66,0x66,0x66,0x00, //  72 'H'
  0x7E,0x18,0x18,0x18,0x18,0x18,0x7E,0x00, //  73 'I'
  0x3E,0x0C,0x0C,0x0C,0x0C,0x6C,0x38,0x00, //  74 'J'
  0x66,0x6C,0x78,0x70,0x78,0x6C,0x66,0x00, //  75 'K'
  0x60,0x60,0x60,0x60,0x60,0x60,0x7E,0x00, //  76 'L'
  0x63,0x77,0x7F,0x6B,0x6B,0x63,0x63,0x00, //  77 'M'
  0x66,0x66,0x76,0x7E,0x6E,0x66,0x66,0x00, //  78 'N'
  0x3C,0x66,0x66,0x66,0x66,0x66,0x3C,0x00, //  79 'O'
  0x7C,0x66,0x66,0x7C,0x60,0x60,0x60,0x00, //  80 'P'
  0x3C,0x66,0x66,0x66,0x6A,0x6C,0x36,0x00, //  81 'Q'
  0x7C,0x66,0x66,0x7C,0x6C,0x66,0x66,0x00, //  82 'R'
  0x3C,0x66,0x60,0x3C,0x06,0x66,0x3C,0x00, //  83 'S'
  0x7E,0x18,0x18,0x18,0x18,0x18,0x18,0x00, //  84 'T'
  0x66,0x66,0x66,0x66,0x66,0x66,0x3C,0x00, //  85 'U'
  0x66,0x66,0x66,0x66,0x66,0x3C,0x18,0x00, //  86 'V'
  0x63,0x63,0x6B,0x6B,0x7F,0x77,0x63,0x00, //  87 'W'
  0x66,0x66,0x3C,0x18,0x3C,0x66,0x66,0x00, //  88 'X'
  0x66,0x66,0x66,0x3C,0x18,0x18,0x18,0x00, //  89 'Y'
  0x7E,0x06,0x0C,0x18,0x30,0x60,0x7E,0x00, //  90 'Z'
  0x38,0x30,0x30,0x30,0x30,0x30,0x38,0x00, //  91 '['
  0x80,0xC0,0x60,0x30,0x18,0x0C,0x06,0x00, //  92 '\\'
  0x38,0x18,0x18,0x18,0x18,0x18,0x38,0x00, //  93 ']'
  0x18,0x3C,0x66,0x00,0x00,0x00,0x00,0x00, //  94 '^'
  0x00,0x00,0x00,0x00,0x00,0x00,0xFE,0x00, //  95 '_'
  0x30,0x30,0x18,0x00,0x00,0x00,0x00,0x00, //  96 '`'
  0x00,0x00,0x3C,0x06,0x3E,0x66,0x3E,0x00, //  97 'a'
  0x60,0x60,0x7C,0x66,0x66,0x66,0x7C,0x00, //  98 'b'
  0x00,0x00,0x3C,0x66,0x60,0x66,0x3C,0x00, //  99 'c'
  0x06,0x06,0x3E,0x66,0x66,0x66,0x3E,0x00, // 100 'd'
  0x00,0x00,0x3C,0x66,0x7E,0x60,0x3C,0x00, // 101 'e'
  0x1C,0x30,0x30,0x7C,0x30,0x30,0x30,0x00, // 102 'f'
  0x00,0x00,0x3E,0x66,0x66,0x3E,0x06,0x3C, // 103 'g'
  0x60,0x60,0x7C,0x66,0x66,0x66,0x66,0x00, // 104 'h'
  0x18,0x00,0x38,0x18,0x18,0x18,0x3C,0x00, // 105 'i'
  0x18,0x00,0x38,0x18,0x18,0x18,0x18,0x70, // 106 'j'
  0x60,0x60,0x66,0x6C,0x78,0x6C,0x66,0x00, // 107 'k'
  0x38,0x18,0x18,0x18,0x18,0x18,0x3C,0x00, // 108 'l'
  0x00,0x00,0x36,0x7F,0x6B,0x63,0x63,0x00, // 109 'm'
  0x00,0x00,0x7C,0x66,0x66,0x66,0x66,0x00, // 110 'n'
  0x00,0x00,0x3C,0x66,0x66,0x66,0x3C,0x00, // 111 'o'
  0x00,0x00,0x7C,0x66,0x66,0x7C,0x60,0x60, // 112 'p'
  0x00,0x00,0x3E,0x66,0x66,0x3E,0x06,0x07, // 113 'q'
  0x00,0x00,0x6C,0x76,0x60,0x60,0x60,0x00, // 114 'r'
  0x00,0x00,0x3E,0x60,0x3C,0x06,0x7C,0x00, // 115 's'
  0x30,0x30,0x7C,0x30,0x30,0x30,0x1C,0x00, // 116 't'
  0x00,0x00,0x66,0x66,0x66,0x66,0x3E,0x00, // 117 'u'
  0x00,0x00,0x66,0x66,0x66,0x3C,0x18,0x00, // 118 'v'
  0x00,0x00,0x63,0x6B,0x6B,0x7F,0x36,0x00, // 119 'w'
  0x00,0x00,0x66,0x3C,0x18,0x3C,0x66,0x00, // 120 'x'
  0x00,0x00,0x66,0x66,0x66,0x3E,0x06,0x3C, // 121 'y'
  0x00,0x00,0x7E,0x0C,0x18,0x30,0x7E,0x00, // 122 'z'
  0x18,0x30,0x30,0x60,0x30,0x30,0x18,0x00, // 123 '{'
  0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x00, // 124 '|'
  0x30,0x18,0x18,0x0C,0x18,0x18,0x30,0x00, // 125 '}'
  0x00,0x66,0xD6,0xCC,0x00,0x00,0x00,0x00, // 126 '~'
  0x10,0x38,0x6C,0xC6,0x82,0x82,0xFE,0x00, // 127 'DEL'
]);

function drawBbcGlyph(col, row, code, physicalColour = 0) {
  let c = code & 0xff;
  if (c < 32 || c > 127) c = 63;
  const glyph = (c - 32) * 8;
  const rgb = hexToRgb(BBC_COLOURS[physicalColour & 7]);
  const x0 = (col | 0) * 8;
  const y0 = (row | 0) * 8;
  for (let gy = 0; gy < 8; gy++) {
    const bits = BBC_MOS_FONT_8X8[glyph + gy];
    const py = y0 + gy;
    if (py < 0 || py >= MODE1_HEIGHT) continue;
    for (let gx = 0; gx < 8; gx++) {
      if ((bits & (0x80 >>> gx)) === 0) continue;
      const px = x0 + gx;
      if (px < 0 || px >= MODE1_WIDTH) continue;
      const o = (py * MODE1_WIDTH + px) * 4;
      framePixels[o] = rgb[0];
      framePixels[o + 1] = rgb[1];
      framePixels[o + 2] = rgb[2];
      framePixels[o + 3] = 255;
    }
  }
}

function drawTitleText(col, row, text, colour = 0, align = 'left') {
  const s = String(text);
  let startCol = col | 0;
  if (align === 'center') startCol -= Math.floor(s.length / 2);
  else if (align === 'right') startCol -= s.length;
  for (let i = 0; i < s.length; i++) drawBbcGlyph(startCol + i, row, s.charCodeAt(i), colour);
}

function fillFrameRect(x, y, width, height, physicalColour) {
  const rgb = hexToRgb(BBC_COLOURS[physicalColour & 7]);
  const x0 = Math.max(0, x|0), y0 = Math.max(0, y|0);
  const x1 = Math.min(MODE1_WIDTH, x0 + (width|0)), y1 = Math.min(MODE1_HEIGHT, y0 + (height|0));
  for (let py = y0; py < y1; py++) {
    let o = (py * MODE1_WIDTH + x0) * 4;
    for (let px = x0; px < x1; px++, o += 4) {
      framePixels[o] = rgb[0]; framePixels[o+1] = rgb[1]; framePixels[o+2] = rgb[2]; framePixels[o+3] = 255;
    }
  }
}

// The BBC screenshot is the authority for the final displayed raster.  The VDU/PLOT
// title rectangle is affected by the BBC display presentation path; these framebuffer
// coordinates reproduce the visible panel boundary in the original output.
const TITLE_PANEL_RECT = Object.freeze({ left: 24, top: 58, right: 276, bottom: 198 });
function drawTitlePanelToFrame() {
  const r = TITLE_PANEL_RECT;
  fillFrameRect(r.left + 1, r.top + 1, r.right - r.left - 1, r.bottom - r.top - 1, 2);
  fillFrameRect(r.left, r.top, r.right - r.left + 1, 1, 0);
  fillFrameRect(r.left, r.bottom, r.right - r.left + 1, 1, 0);
  fillFrameRect(r.left, r.top, 1, r.bottom - r.top + 1, 0);
  fillFrameRect(r.right, r.top, 1, r.bottom - r.top + 1, 0);
}
function titlePalette() { logicalPalette = [2, 5, 3, 0]; state.viewportXOffset = 0; logicalClipLeft=0; logicalClipRight=0x50; }
function renderCastScreen() {
  titlePalette(); clearFrame();
  const t = FRAK_DATA.title;
  drawSpriteAt(0x22, t.logoX, t.logoY);
  drawSpriteAt(SPRITE_TROGG_FRAME1, t.troggX, t.troggY);
  drawSpriteAt(FRAK_DATA.constants.SPRITE_SCRUBBLY, t.scrubblyX, t.scrubblyY);
  drawSpriteAt(FRAK_DATA.constants.SPRITE_HOOTER, t.hooterX, t.hooterY);
  drawSpriteAt(FRAK_DATA.constants.SPRITE_POGLET, t.pogletX, t.pogletY);

  // The credits stream switches to text window rows 25..31, selects yellow as
  // its background and clears that window.  It then PLOTs the black separator
  // at graphics Y=&00E0 (screen scanline 199).
  fillFrameRect(0, 200, MODE1_WIDTH, 56, 3); // physical yellow
  fillFrameRect(0, 199, MODE1_WIDTH, 1, 0);

  // Literal VDU 31 coordinates from RuntimeGameEntry.
  drawTitleText(16,3,'The Cast');
  drawTitleText(16,4,'--------');
  drawTitleText(26,7,'Trogg');
  drawTitleText(19,9,'vs.');
  drawTitleText(25,13,'Scrubbly');
  drawTitleText(26,17,'Hooter');
  drawTitleText(26,21,'Poglet');

  // Coordinates are relative to the row-25 credit text window.
  drawTitleText(5,26,'Game concepts by DCE,OMP & BOF');
  drawTitleText(1,28,'Programming beyond belief by *Orlando*');
  drawTitleText(7,30,'(C) Aardvark Software 1984');
  ctx.putImageData(frame, 0, 0);
}
let titleBackdropPixels = null;
let highScoreBackdropPixels = null;

function titlePseudoRandomChars(recordIndex) {
  const o = recordIndex * HIGH_SCORE_RECORD_SIZE;
  const hi = state.highScores[o+3], mid = state.highScores[o+4], lo = state.highScores[o+5];
  // ShowHighScores copies score bytes to stack-page scratch as
  // [lo,mid,hi,lo,mid,hi]. PrintPseudoRandomTitleChar then consumes three
  // overlapping triples, carrying the LSR(seed) carry into ADC exactly once.
  const scratch = [lo,mid,hi,lo,mid,hi];
  const map = FRAK_DATA.title.characterMap;
  const seeds = FRAK_DATA.title.randomCharSeeds;
  const out=[];
  for (let i=0;i<3;i++) {
    const seed = seeds[i] & 0xff;
    let carry = seed & 1;
    let sum = scratch[i] + scratch[i+1] + carry;
    let value = sum & 0xff;
    carry = sum > 0xff ? 1 : 0;
    const sub = scratch[i+2] + (1-carry);
    const diff = value - sub;
    value = diff & 0xff;
    value ^= seed;
    while (value >= map.length) value -= map.length;
    out.push(String.fromCharCode(map[value]));
  }
  return out.join('');
}
function formatHighScoreBcd(hi, mid, lo) {
  // ShowHighScores enters the three PrintPackedBCD calls with CLC. PrintBCDNibble
  // suppresses zero nibbles until the first non-zero digit sets carry; the final
  // literal zero is always emitted. Thus &00,&01,&00 displays as 1000, not 0001000.
  const digits = [hi>>4, hi&15, mid>>4, mid&15, lo>>4, lo&15];
  let out = '', started = false;
  for (const d of digits) {
    if (d || started) { out += String.fromCharCode(48 + d); started = true; }
  }
  return (out || '') + '0';
}
function showHighScores() {
  const rows = FRAK_DATA.title.highScoreRows ?? [9,11,12,13,14,15];
  for (let row = 0; row < HIGH_SCORE_COUNT; row++) {
    const o = row * HIGH_SCORE_RECORD_SIZE;
    const initials = String.fromCharCode(state.highScores[o], state.highScores[o+1], state.highScores[o+2]);
    const score = formatHighScoreBcd(state.highScores[o+3], state.highScores[o+4], state.highScores[o+5]);
    const y = rows[row] ?? (9+row);
    drawTitleText(15, y, `${initials} ${score}`, 0);
    drawTitleText(28, y, `(${titlePseudoRandomChars(row)})`, 0);
  }
}
function drawTitleOverlay() {
  // Positions below are calibrated to the original BBC raster screenshot while
  // retaining the recovered VDU row structure.
  drawTitleText(11,8,'Grandmaster Frak...',0);
  drawTitleText(6,10,'...and the Furious Five',0);
  drawTitleText(4,23,'(C) Aardvark Software 1984',0);
  showHighScores();
}
function renderTitleBanner() {
  titlePalette(); clearFrame();
  drawTitlePanelToFrame();
  drawTitleOverlay();
  ctx.putImageData(frame,0,0);
}

// 6502 HighScoreInsert (&164D) does not create a separate browser UI.  It calls
// PrintTitleBanner/ShowHighScores over the existing game raster, then writes two
// instruction strings with VDU 31 at (9,17) and (9,19).  The live candidate
// character is written directly at the qualifying high-score row and backspaced
// over until Jump is pressed.  Keep that presentation here rather than adding
// browser-only headings or instructions outside the title panel.
function renderHighScoreEntry(showCursor = true) {
  if (highScoreBackdropPixels) framePixels.set(highScoreBackdropPixels);
  else clearFrame();
  drawTitlePanelToFrame();
  drawTitleOverlay();

  drawTitleText(9,17,'<-+-> to select letter',0);
  drawTitleText(9,19,"'Jump' to enter letter",0);

  if (showCursor && state.highScoreInitialIndex < HIGH_SCORE_INITIALS) {
    const rows = FRAK_DATA.title.highScoreRows ?? [9,11,12,13,14,15];
    const row = rows[state.highScoreRank] ?? (9 + state.highScoreRank);
    const col = 15 + state.highScoreInitialIndex; // matches ShowHighScores initials column
    drawBbcGlyph(col, row, state.highScoreEntryChar, 0);
    // The original calls ShowTextCursor before entering the selector loop.
    fillFrameRect(col * 8, row * 8 + 7, 8, 1, 0);
  }
  ctx.putImageData(frame,0,0);
}
function renderTitleTransitionScene(finalTrogg = false) {
  if (titleBackdropPixels) framePixels.set(titleBackdropPixels);
  drawTitlePanelToFrame();
  // PrintTitleBanner/ShowHighScores already exist before the transition actors are
  // drawn in the 6502 sequence, so actors must layer on top of the text/panel.
  drawTitleOverlay();
  if (state.objectSprite[0] !== OBJECT_EMPTY)
    drawSpriteAt(state.objectSprite[0], state.objectX[0], state.objectY[0]);
  if (state.objectSprite[1] !== OBJECT_EMPTY)
    drawSpriteAt(state.objectSprite[1], state.objectX[1], state.objectY[1]);
  if (finalTrogg && state.objectSprite[0] !== OBJECT_EMPTY) {
    // &5B is only the FRAK! bubble composite. The original does NOT replace or
    // erase Trogg: it draws this overlay at slot-0 X and TITLE_FINAL_Y.
    drawSpriteAt(FRAK_DATA.constants.SPRITE_TROGG_DEATH ?? 0x5b, state.objectX[0], TITLE_FINAL_Y);
  }
  ctx.putImageData(frame,0,0);
}
function nextTransitionSpriteIndex(index) {
  const seq = FRAK_DATA.title.transitionSequence;
  let y=index;
  for (let guard=0;guard<32;guard++) {
    y++;
    let value=seq[y];
    if (value !== undefined && value < 0x80) return [y,value];
    do { y--; value=seq[y]; } while (y>0 && value < 0x80);
  }
  return [index,OBJECT_EMPTY];
}
function beginTitleTransitionLeft() {
  logicalClipLeft=TITLE_CLIP_LEFT; logicalClipRight=TITLE_CLIP_RIGHT;
  state.mode='titleTransitionLeft'; state.titleTransitionSlot=0;
  state.objectX[0]=0; state.objectY[0]=TITLE_TRANSITION_Y; state.objectDX[0]=1;
  state.objectDY[0]=1; state.objectSprite[0]=FRAK_DATA.title.transitionSequence[1];
  state.objectSprite[1]=OBJECT_EMPTY;
  state.titleTransitionFramesRemaining=TITLE_TRANSITION_FRAMES;
  state.titleTransitionTickDivider=TITLE_TRANSITION_FRAME_DELAY;
  renderTitleTransitionScene(); updateInfo();
}
function beginTitleTransitionRight() {
  state.mode='titleTransitionRight'; state.titleTransitionSlot=1;
  state.objectX[1]=0x50; state.objectY[1]=TITLE_TRANSITION_Y; state.objectDX[1]=0xff;
  state.objectDY[1]=6; state.objectSprite[1]=FRAK_DATA.title.transitionSequence[6];
  state.titleTransitionFramesRemaining=TITLE_TRANSITION_FRAMES;
  state.titleTransitionTickDivider=TITLE_TRANSITION_FRAME_DELAY;
  renderTitleTransitionScene(); updateInfo();
}
function advanceTitleTransitionFrame() {
  const slot=state.titleTransitionSlot;
  state.objectX[slot]=u8(state.objectX[slot]+signed8(state.objectDX[slot]));
  const [idx,sprite]=nextTransitionSpriteIndex(state.objectDY[slot]);
  state.objectDY[slot]=idx; state.objectSprite[slot]=sprite;
  state.titleTransitionFramesRemaining--;
  renderTitleTransitionScene();
  if (state.titleTransitionFramesRemaining<=0) {
    if (state.mode==='titleTransitionLeft') beginTitleTransitionRight();
    else {
      state.mode='titleTransitionDelay'; state.titlePostDelay=TITLE_TRANSITION_DELAY;
      renderTitleTransitionScene(); updateInfo();
    }
  }
}
function runtimeGameEntry() {
  state.mode='titleCast'; state.running=false; state.paused=false;
  state.musicInhibit=true; state.currentTune=null; stopAllAudio();
  state.transformCycle=0; state.titleTicksRemaining=TITLE_TIMEOUT_TICKS;
  state.titleRandomDrawCount=0; state.titleFrameDirty=true;
  titleBackdropPixels=null; highScoreBackdropPixels=null;
  renderCastScreen(); updateInfo();
}
function titleStartSequence() {
  state.mode='titleScatter'; state.titleRandomDrawCount=TITLE_RANDOM_DRAW_COUNT;
  state.titleRandomSprite=FRAK_DATA.title.randomSprites[randomUpToA(3)];
  logicalClipLeft=0; logicalClipRight=0x50;
  titlePalette(); clearFrame(); ctx.putImageData(frame,0,0); updateInfo();
}
function titleTick() {
  if (state.mode==='titleCast') {
    if (--state.titleTicksRemaining<=0) titleStartSequence();
    return;
  }
  if (state.mode==='titleScatter') {
    const x=randomUpToA(0x50), y=randomUpToA(0xff);
    drawSpriteAt(state.titleRandomSprite,x,y); ctx.putImageData(frame,0,0);
    if (--state.titleRandomDrawCount<=0) {
      // PrintTitleBanner falls through into ShowHighScores in the original.
      // Snapshot the 125-sprite backdrop so the two masked transition actors can
      // be redrawn without leaving trails while the text overlay remains fixed.
      titleBackdropPixels=new Uint8ClampedArray(framePixels);
      beginTitleTransitionLeft();
    }
    return;
  }
  if (state.mode==='titleTransitionLeft' || state.mode==='titleTransitionRight') {
    if (--state.titleTransitionTickDivider<=0) {
      state.titleTransitionTickDivider=TITLE_TRANSITION_FRAME_DELAY;
      advanceTitleTransitionFrame();
    }
    return;
  }
  if (state.mode==='titleTransitionDelay') {
    if (--state.titlePostDelay<=0) {
      state.mode='titleFinalWait'; state.titleFinalWait=TITLE_FINAL_WAIT;
      renderTitleTransitionScene(true); updateInfo();
    }
    return;
  }
  if (state.mode==='titleFinalWait') {
    if (--state.titleFinalWait<=0) titleStartSequence();
    return;
  }
  if (state.mode==='titleScores') {
    if (--state.titleTicksRemaining<=0) titleStartSequence();
  }
}
function gameStartTitleLoop() {
  state.running=false; state.paused=false; state.musicInhibit=true; state.currentTune=null;
  stopAllAudio(); titleBackdropPixels=null; highScoreBackdropPixels=null;
  titleStartSequence();
}
function startFromTitle() { ensureAudio(); newGame(); }
function scoreCompareRecord(recordIndex) {
  const o=recordIndex*6;
  for (const [a,b] of [[state.scoreHi,state.highScores[o+3]],[state.scoreMid,state.highScores[o+4]],[state.scoreLo,state.highScores[o+5]]]) {
    if (a>b) return 1; if(a<b) return -1;
  }
  return 0;
}
function highScoreInsert() {
  let rank=-1;
  for(let i=0;i<HIGH_SCORE_COUNT;i++){ if(scoreCompareRecord(i)>=0){rank=i;break;} }
  if(rank<0){ gameStartTitleLoop(); return false; }
  for(let i=HIGH_SCORE_COUNT-1;i>rank;i--){
    for(let j=0;j<6;j++) state.highScores[i*6+j]=state.highScores[(i-1)*6+j];
  }
  const o=rank*6; state.highScores[o]=state.highScores[o+1]=state.highScores[o+2]=0x20;
  state.highScores[o+3]=state.scoreHi; state.highScores[o+4]=state.scoreMid; state.highScores[o+5]=state.scoreLo;
  state.highScoreRank=rank; state.highScoreInitialIndex=0; state.highScoreEntryChar=0x41;
  // HighScoreInsert keeps the game raster outside the central title panel.
  highScoreBackdropPixels = new Uint8ClampedArray(framePixels);
  state.mode='highScoreEntry'; state.running=false; state.musicInhibit=true; stopAllAudio(); renderHighScoreEntry(); updateInfo();
  return true;
}
function cycleHighScoreChar(delta) {
  let c=state.highScoreEntryChar+delta; if(c>0x7e)c=0x20; if(c<0x20)c=0x7e; state.highScoreEntryChar=c; renderHighScoreEntry();
}
function commitHighScoreChar() {
  if(state.mode!=='highScoreEntry')return;
  state.highScores[state.highScoreRank*6+state.highScoreInitialIndex]=state.highScoreEntryChar;
  state.highScoreInitialIndex++;
  if(state.highScoreInitialIndex>=3){
    // Original: HideTextCursor; wait &50 ticks; then return to the title loop.
    state.mode='titleScores'; state.titleTicksRemaining=0x50; renderHighScoreEntry(false); updateInfo(); return;
  }
  // Original keeps HighScoreEntryChar unchanged for the next initial.
  renderHighScoreEntry();
}

// 6502: SpriteTraversal (&1D2E). Composite child triples remain original data.
function spriteTraversal(sprite, originX, originY, visitor, depth = 0) {
  if (sprite === OBJECT_EMPTY || sprite >= 92 || depth > 16) return;
  const d = spriteDescriptor(sprite);
  const x = originX + d.xOffset;
  const y = originY + d.yOffset;
  const width = d.widthFlags & 0x7f;
  if (width !== 0) {
    visitor(sprite, x, y, d);
    return;
  }
  const defOffset = d.defLo | (d.defHi << 8);
  for (let child = 0; child < d.heightCount; child++) {
    const p = defOffset + child * 3;
    spriteTraversal(
      FRAK_DATA.spriteRegion[p],
      x + signed8(FRAK_DATA.spriteRegion[p + 1]),
      y + signed8(FRAK_DATA.spriteRegion[p + 2]),
      visitor,
      depth + 1
    );
  }
}

// 6502: DirectSpriteRenderer (&1E36)
function directSpriteRenderer(sprite, logicalX, logicalY, d) {
  const widthBytes = d.widthFlags & 0x7f;
  const height = d.heightCount;
  const descriptorReverse = (d.widthFlags & 0x80) !== 0;
  const verticalFlip = (state.transformCycle & 1) !== 0;
  const effectiveReverse = descriptorReverse;
  const solid = (d.defHi & 0x80) !== 0;
  const defOffset = d.defLo | (d.defHi << 8);

  for (let row = 0; row < height; row++) {
    // The original forward pixel operator starts at definition+height-1 and
    // walks backwards.  The display transform changes the screen-Y traversal;
    // it must NOT also reverse the source rows here or the two inversions cancel
    // and an upside-down screen contains upright sprites.
    const sourceRow = effectiveReverse ? row : (height - 1 - row);
    const worldY = logicalY + row;
    const screenY = verticalFlip ? worldY : (255 - worldY);
    for (let colByte = 0; colByte < widthBytes; colByte++) {
      const byte = solid ? d.defLo : FRAK_DATA.spriteRegion[defOffset + colByte * height + sourceRow];
      const pixels = mode1Pixels(byte);
      const screenByteX = logicalX + colByte - state.viewportXOffset;
      if (screenByteX < logicalClipLeft || screenByteX >= logicalClipRight) continue;
      const px0 = screenByteX * MODE1_X_SCALE;
      for (let p = 0; p < 4; p++) putLogicalPixel(px0 + p, screenY, pixels[p], !solid);
    }
  }
}

function drawSpriteAt(sprite, x, y) { spriteTraversal(sprite, x, y, directSpriteRenderer); }

function drawAllObjects() {
  for (let slot = state.objectSprite.length - 1; slot >= 0; slot--) {
    const sprite = state.objectSprite[slot];
    if (sprite !== OBJECT_EMPTY) drawSpriteAt(sprite, state.objectX[slot], state.objectY[slot]);
  }
}

function renderFrame() {
  clearFrame();
  drawAllObjects();
  // CommitPlayer_DeathEffects draws SPRITE_TROGG_DEATH on top of the normal
  // player sprite.  Descriptor &5B contains only the FRAK! speech bubble child.
  if (state.playerDead) drawSpriteAt(FRAK_DATA.constants.SPRITE_TROGG_DEATH ?? 0x5b,
                                     state.objectX[TROGG_SLOT], state.objectY[TROGG_SLOT]);
  ctx.putImageData(frame, 0, 0);
}

// ---------------------------------------------------------------------------
// Collision geometry: semantic translation of ComputePrimitiveBounds,
// AccumulateSpriteBounds, TestPrimitiveBounds and CollisionScan.
// ---------------------------------------------------------------------------

function primitiveBoundsForSprite(sprite, x, y) {
  const out = [];
  spriteTraversal(sprite, x, y, (_s, px, py, d) => {
    const width = d.widthFlags & 0x7f;
    out.push({ left: px, right: px + width, bottom: py, top: py + d.heightCount });
  });
  return out;
}

function boundsOverlap(a, b) {
  return a.left < b.right && a.right > b.left && a.bottom < b.top && a.top > b.bottom;
}

function collisionScan(mask, sourceSlot, sourceBounds = null) {
  state.collidedObjectSlot = -1;
  state.collidedQueueTag = '';
  const source = sourceBounds ?? primitiveBoundsForSprite(
    state.objectSprite[sourceSlot], state.objectX[sourceSlot], state.objectY[sourceSlot]
  );
  if (!source.length) return false;

  for (const [tag, q] of Object.entries(QUEUES)) {
    if (mask !== 0xff && (q.mask & mask) === 0) continue;
    for (let slot = q.first; slot < q.end; slot++) {
      if (slot === sourceSlot || state.objectSprite[slot] === OBJECT_EMPTY) continue;
      const candidate = primitiveBoundsForSprite(state.objectSprite[slot], state.objectX[slot], state.objectY[slot]);
      let hit = false;
      for (const a of candidate) {
        for (const b of source) {
          if (boundsOverlap(a, b)) { hit = true; break; }
        }
        if (hit) break;
      }
      if (hit) {
        state.collidedObjectSlot = slot;
        state.collidedQueueTag = tag;
        return true;
      }
    }
  }
  return false;
}

function scanObjectCollisions(mask, sourceSlot) { return collisionScan(mask, sourceSlot); }

// 6502: TestLadderCollision (&0E0B)
function testLadderCollision(probeY, sourceSlot = TROGG_SLOT) {
  const x = state.objectX[sourceSlot];
  const bottom = probeY - LADDER_PROBE_BOTTOM_OFFSET;
  return collisionScan(COLLIDE_LADDER, sourceSlot, [{
    left: x, right: x + 1, bottom, top: bottom + LADDER_PROBE_HEIGHT
  }]);
}

// 6502: TestFloorCollision (&0E5F)
function testFloorCollision(probeY, sourceSlot = TROGG_SLOT) {
  const x = state.objectX[sourceSlot];
  return collisionScan(COLLIDE_FLOOR, sourceSlot, [{
    left: x, right: x + 1, bottom: probeY - 1, top: probeY
  }]);
}

// 6502: TestPlayerMove (&1085). This retains the original swept narrow probe:
// X spans proposed X..X+1; vertical span is current Y to current Y+DY.
function testPlayerMove(sourceSlot = TROGG_SLOT) {
  const dx = signed8(state.objectDX[sourceSlot]);
  const dy = signed8(state.objectDY[sourceSlot]);
  if (dy >= 0) return false;
  const x = state.objectX[sourceSlot] + dx;
  const y = state.objectY[sourceSlot];
  const bottom = y + dy;
  const hit = collisionScan(COLLIDE_FLOOR, sourceSlot, [{
    left: x, right: x + 1, bottom, top: y
  }]);
  if (!hit) return false;

  // The original has a special fast-fall probe branch. Preserve its practical
  // effect: a floor crossed by the swept probe remains a collision even at high fall speed.
  if (dy <= PLAYER_FLOOR_PROBE_DY_LIMIT) return true;
  const floorY = state.objectY[state.collidedObjectSlot];
  return (floorY - bottom - PLAYER_LANDING_Y_ADJUST) < 0;
}

// ---------------------------------------------------------------------------
// Keyboard shim preserving Frak's original control meanings.
// Z left, X right, ' up/jump, / down, RETURN yo-yo.
// Arrow keys and Space are browser convenience aliases only.
// ---------------------------------------------------------------------------

function keyHeld(...names) { return names.some(k => pressed.has(k)); }
function readHorizontal() {
  let x = 0;
  if (keyHeld('z', 'arrowleft')) x--;
  if (keyHeld('x', 'arrowright')) x++;
  return x;
}
function readVertical(currentY) {
  let y = currentY;
  let delta = 0;
  // Browser input shim: retain a brief vertical key press until the next
  // 4-tick player update.  The BBC code polls only on player updates; without
  // this host-side latch a fast browser key tap can occur wholly between two
  // 80 ms samples and vanish.  Held-key behaviour and Frak's movement cadence
  // are unchanged.
  if (keyHeld("'", 'arrowup') || state.inputLatchUp) delta += VERTICAL_INPUT_STEP;
  if (keyHeld('/', 'arrowdown') || state.inputLatchDown) delta -= VERTICAL_INPUT_STEP;
  if ((state.transformCycle & 1) !== 0) delta = -delta;
  y += delta;
  return u8(y);
}
function readYoyoControl() { return keyHeld('enter', ' '); }

// ---------------------------------------------------------------------------
// Trogg movement / physics. These routines preserve the Stage 10 state-machine
// split rather than replacing it with a generic platform-game physics engine.
// ---------------------------------------------------------------------------

function latchJumpInput() { state.jumpInputHistory |= 0x80; }

function tryAttachLadder(proposedY) {
  if (!testLadderCollision(proposedY, TROGG_SLOT)) return null;

  // Original TryAttachLadder (&0E2F) does more than test overlap.  When Trogg
  // is standing, it only attaches if the requested vertical direction points
  // toward the ladder's origin.  This prevents grabbing the wrong end of a
  // ladder that happens to overlap the long narrow probe.  Airborne Trogg may
  // attach from either side, matching the BMI fast path in the 6502 routine.
  if (!state.playerAirborne) {
    const currentY = state.objectY[TROGG_SLOT];
    const ladderSlot = state.collidedObjectSlot;
    const movingPositive = u8(proposedY) >= currentY;   // CPY ObjectY carry
    const ladderPositive = state.objectY[ladderSlot] >= currentY; // CMP ObjectY carry
    if (movingPositive !== ladderPositive) return null;
  }

  state.playerClimbing = true;
  state.objectDX[TROGG_SLOT] = 0;
  return { sprite: SPRITE_TROGG_CLIMB_A, y: u8(proposedY) };
}

function startPlayerJump(sprite) {
  state.objectDY[TROGG_SLOT] = u8(PLAYER_INITIAL_JUMP_DY);
  state.playerAirborne = true;
  const dx = signed8(state.objectDX[TROGG_SLOT]);
  if (dx > 0) sprite = SPRITE_TROGG_FRAME2;
  else if (dx < 0) sprite = SPRITE_TROGG_FRAME6;
  return updateAirbornePlayer(sprite);
}

// 6502: UpdateAirbornePlayer (&10DE)
function updateAirbornePlayer(sprite) {
  const currentY = state.objectY[TROGG_SLOT];
  const controlY = readVertical(currentY);
  const oldDy = signed8(state.objectDY[TROGG_SLOT]);
  let proposedY = currentY + oldDy;

  if (proposedY < 0) {
    proposedY = 0;
    return landOrDie(sprite, proposedY);
  }
  if (oldDy >= 0 && proposedY >= PLAYER_Y_CEILING) {
    state.objectDY[TROGG_SLOT] = u8(-oldDy);
    proposedY = PLAYER_Y_CEILING;
  }

  state.objectDY[TROGG_SLOT] = u8(signed8(state.objectDY[TROGG_SLOT]) - 1);
  const newDy = signed8(state.objectDY[TROGG_SLOT]);

  if (controlY !== currentY && newDy >= PLAYER_MAX_SAFE_FALL_DY) {
    const attached = tryAttachLadder(controlY);
    if (attached) return landOrDie(attached.sprite, attached.y);
  }

  if (testPlayerMove(TROGG_SLOT)) {
    const floorY = state.objectY[state.collidedObjectSlot];
    return landOrDie(sprite, floorY + 1);
  }
  return { sprite, y: u8(proposedY) };
}

function landOrDie(sprite, y) {
  state.playerAirborne = false;
  if (signed8(state.objectDY[TROGG_SLOT]) < PLAYER_MAX_SAFE_FALL_DY) markPlayerDead('fatal fall');
  state.objectDY[TROGG_SLOT] = 0xff;
  return { sprite, y: u8(y) };
}

// 6502: UpdateClimbingPlayer (&113B)
function updateClimbingPlayer(sprite) {
  const currentY = state.objectY[TROGG_SLOT];
  if (!testLadderCollision(currentY, TROGG_SLOT)) {
    state.playerClimbing = false;
    state.playerAirborne = true;
    state.objectDX[TROGG_SLOT] = 0;
    return { sprite: state.playerFrameSprite, y: currentY };
  }

  // Preserve the ladder slot found by the initial collision test.  The original
  // routine uses this object's Y origin to decide which end of the ladder Trogg
  // is approaching before doing any floor-edge detach test.
  const ladderSlot = state.collidedObjectSlot;
  const ladderY = state.objectY[ladderSlot];
  const proposedY = readVertical(currentY);
  if (proposedY !== currentY) sprite ^= 0x07; // original climb A/B toggle

  // Original correction occurs when RandomUpToA(2) returns an odd value.
  if ((randomUpToA(2) & 1) !== 0 && ladderSlot >= 0) {
    state.objectDX[TROGG_SLOT] = u8(sign(state.objectX[ladderSlot] - state.objectX[TROGG_SLOT]));
  } else {
    state.objectDX[TROGG_SLOT] = 0;
  }

  // Faithful semantic form of &1169-&119D.  Stage 2 simplified this to
  // "if proposed Y touches a floor, detach", which made downward climbing
  // through a platform immediately snap Trogg back onto that platform.
  if (proposedY >= ladderY) {
    // At/above this end of the ladder, only a positive-Y move has special
    // floor-edge handling.  Negative-Y movement continues along the ladder.
    if (proposedY <= currentY) return { sprite, y: proposedY };

    if (!testFloorCollision(currentY, TROGG_SLOT)) return { sprite, y: proposedY };
    const floorSlot = state.collidedObjectSlot; // retained by original across second probe
    if (testFloorCollision(proposedY, TROGG_SLOT)) return { sprite, y: proposedY };

    state.playerClimbing = false;
    return { sprite: state.playerFrameSprite, y: u8(state.objectY[floorSlot] + 1) };
  }

  // Below the ladder origin, only negative-Y movement can detach onto a floor.
  if (proposedY >= currentY) return { sprite, y: proposedY };
  if (!testFloorCollision(proposedY, TROGG_SLOT)) return { sprite, y: proposedY };

  const floorSlot = state.collidedObjectSlot;
  state.playerClimbing = false;
  return { sprite: state.playerFrameSprite, y: u8(state.objectY[floorSlot] + 1) };
}

// 6502: UpdatePlayerMotion (&0FEB)
function updatePlayerMotion() {
  state.jumpInputHistory >>>= 1;
  let sprite = state.objectSprite[TROGG_SLOT];
  let y = state.objectY[TROGG_SLOT];

  if (state.yoyoActive) return continueYoyoAttack();
  if (state.playerAirborne) return updateAirbornePlayer(sprite);
  if (state.playerClimbing) return updateClimbingPlayer(sprite);

  const horizontal = readHorizontal();
  state.objectDX[TROGG_SLOT] = u8(horizontal);
  if (horizontal !== 0) state.playerHorizontalStep = horizontal;
  state.playerFrameSprite = sprite;

  const proposedY = readVertical(y);
  if (proposedY === y) {
    latchJumpInput();
  } else {
    const attached = tryAttachLadder(proposedY);
    if (attached) return attached;
    if (signed8(proposedY - y) < 0) {
      latchJumpInput();
    } else if ((state.jumpInputHistory & 0x40) !== 0) {
      return startPlayerJump(sprite);
    }
  }

  if (horizontal > 0) {
    state.walkAnimationPhase = (state.walkAnimationPhase + 1) & 3;
    sprite = PLAYER_WALK_FRAMES_RIGHT[state.walkAnimationPhase];
  } else if (horizontal < 0) {
    state.walkAnimationPhase = (state.walkAnimationPhase + 3) & 3;
    sprite = PLAYER_WALK_FRAMES_LEFT[state.walkAnimationPhase];
  }

  // Original PlayerMotion_CheckYoyo dispatches immediately into UpdateYoyoAttack.
  if (readYoyoControl()) return updateYoyoAttack(sprite);

  if (!testPlayerMove(TROGG_SLOT)) {
    state.playerAirborne = true;
  } else {
    state.supportObjectSlot = state.collidedObjectSlot;
    y = u8(state.objectY[state.collidedObjectSlot] + 1);
  }
  return { sprite, y };
}

// 6502: RetractYoyo (&1074)
function retractYoyo() {
  state.yoyoExtensionDirection = -1;
  // EOR #&FE flips signed unit direction: +1 -> -1, -1 -> +1.
  const reversed = -signed8(state.playerHorizontalStep);
  state.objectDX[YOYO_HEAD_SLOT] = u8(reversed);
  if (reversed > 0) state.objectDX[YOYO_STRING_SLOT] = u8(reversed);
}

function finishYoyo() {
  state.yoyoActive = false;
  state.objectSprite[YOYO_STRING_SLOT] = OBJECT_EMPTY;
  state.objectSprite[YOYO_HEAD_SLOT] = OBJECT_EMPTY;
  state.objectDX[YOYO_STRING_SLOT] = 0;
  state.objectDX[YOYO_HEAD_SLOT] = 0;
  return { sprite: state.playerFrameSprite, y: state.objectY[TROGG_SLOT] };
}

function removeYoyoHitObject(slot) {
  retractYoyo();
  state.objectSprite[slot] = OBJECT_EMPTY;
  addScoreBCD(SCORE_MONSTER_BCD);
}

// Original monster hit path spends five 50 Hz ticks moving the struck monster
// eight horizontal steps per tick while the player update is blocked.
function yoyoKnockbackTick() {
  if (state.yoyoKnockbackTicks <= 0 || state.yoyoHitSlot < 0) return false;
  const slot = state.yoyoHitSlot;
  state.objectX[slot] = u8(state.objectX[slot] + signed8(state.playerHorizontalStep) * YOYO_KNOCKBACK_STEPS);
  state.yoyoKnockbackTicks--;
  if (state.yoyoKnockbackTicks === 0) {
    removeYoyoHitObject(slot);
    state.yoyoHitSlot = -1;
  }
  renderFrame();
  updateInfo();
  return true;
}

// 6502: UpdateYoyoAttack (&0E8F)
function updateYoyoAttack(playerSprite) {
  state.playerFrameSprite = playerSprite;
  state.yoyoActive = true;
  state.objectDX[TROGG_SLOT] = 0;

  const step = signed8(state.playerHorizontalStep) || 1;
  state.objectDX[YOYO_HEAD_SLOT] = u8(step);
  let headX = state.objectX[TROGG_SLOT] + step;
  if (step < 0) headX -= YOYO_HEAD_X_OFFSET;
  headX = u8(headX);
  state.objectX[YOYO_HEAD_SLOT] = headX;
  state.yoyoBaseX = headX;
  state.objectX[YOYO_STRING_SLOT] = u8(headX + YOYO_HEAD_X_OFFSET);
  state.objectY[YOYO_HEAD_SLOT] = u8(state.objectY[TROGG_SLOT] + YOYO_VERTICAL_OFFSET);
  state.objectY[YOYO_STRING_SLOT] = u8(state.objectY[YOYO_HEAD_SLOT] + 1);
  state.yoyoExtensionDirection = 1;
  state.yoyoSegmentPhase = 0;
  state.yoyoExtensionCount = 0xff;
  state.yoyoAnimationIndex = 0xff;
  state.objectDX[YOYO_STRING_SLOT] = step < 0 ? 0xff : 0;
  state.objectSprite[TROGG_SLOT] = step < 0 ? SPRITE_TROGG_YOYO_LEFT : SPRITE_TROGG_YOYO_RIGHT;
  return continueYoyoAttack();
}

// 6502: ContinueYoyoAttack (&0EDD), one state-machine advance.
function continueYoyoAttack() {
  let sprite = state.objectSprite[TROGG_SLOT];
  const y = state.objectY[TROGG_SLOT];

  state.yoyoExtensionCount = u8(state.yoyoExtensionCount + 1);

  let phase = state.yoyoSegmentPhase + signed8(state.objectDX[YOYO_HEAD_SLOT]);
  if (phase < 0) phase = 3;
  else if (phase >= 4) phase = 0;
  state.yoyoSegmentPhase = phase;
  state.objectSprite[YOYO_HEAD_SLOT] = YOYO_HEAD_SPRITES[phase];

  const step = signed8(state.playerHorizontalStep) || 1;
  if (step === signed8(state.objectDX[YOYO_HEAD_SLOT])) {
    const headX = state.objectX[YOYO_HEAD_SLOT];
    if (headX >= YOYO_RIGHT_LIMIT || state.yoyoExtensionCount >= YOYO_MAX_EXTENSION ||
        (state.yoyoExtensionCount >= YOYO_MIN_EXTENSION && !readYoyoControl())) {
      retractYoyo();
    }
  }

  // Yoyo_MoveComponents adds each component DX twice.
  state.objectX[YOYO_HEAD_SLOT] = u8(state.objectX[YOYO_HEAD_SLOT] + 2 * signed8(state.objectDX[YOYO_HEAD_SLOT]));
  state.objectX[YOYO_STRING_SLOT] = u8(state.objectX[YOYO_STRING_SLOT] + 2 * signed8(state.objectDX[YOYO_STRING_SLOT]));

  state.yoyoAnimationIndex = u8(state.yoyoAnimationIndex + state.yoyoExtensionDirection);
  // Normal play stays within 0..12. Preserve the adjacent-table edge case
  // conservatively by hiding the string if an unusual collision underflows it.
  if (state.yoyoAnimationIndex >= 0 && state.yoyoAnimationIndex < YOYO_STRING_SPRITES.length)
    state.objectSprite[YOYO_STRING_SLOT] = YOYO_STRING_SPRITES[state.yoyoAnimationIndex];
  else state.objectSprite[YOYO_STRING_SLOT] = OBJECT_EMPTY;

  if (state.objectX[YOYO_HEAD_SLOT] === state.yoyoBaseX) return finishYoyo();

  const mask = state.countdownExpired ? COLLIDE_YOYO_DARK : COLLIDE_YOYO;
  if (scanObjectCollisions(mask, YOYO_HEAD_SLOT)) {
    playSoundBlock('yoyoHit', null, 0.20);
    const hit = state.collidedObjectSlot;
    const tag = state.collidedQueueTag;
    if (tag === 'M') {
      state.yoyoKnockbackTicks = YOYO_KNOCKBACK_FRAMES;
      state.yoyoHitSlot = hit;
    } else {
      removeYoyoHitObject(hit);
    }
  }

  sprite = state.objectSprite[TROGG_SLOT];
  return { sprite, y };
}

// 6502: UpdatePlayerFrame (&11AC), semantic commit path.
function updatePlayerFrame() {
  if (state.playerDead || state.screenCompletePending || state.paused || state.mode !== 'playing') return;

  const oldX=state.objectX[TROGG_SLOT], oldY=state.objectY[TROGG_SLOT], oldSprite=state.objectSprite[TROGG_SLOT];
  const motion = updatePlayerMotion();
  // Consume one-shot browser vertical latches only after the complete movement
  // calculation, so every ReadVertical call made by this original player update
  // sees the same key state.
  state.inputLatchUp = false;
  state.inputLatchDown = false;
  let proposedX = state.objectX[TROGG_SLOT] + signed8(state.objectDX[TROGG_SLOT]);
  if (proposedX < PLAYER_X_MIN || proposedX >= PLAYER_X_MAX_EXCLUSIVE) proposedX = state.objectX[TROGG_SLOT];

  if (proposedX !== state.objectX[TROGG_SLOT]) {
    if (proposedX > state.objectX[TROGG_SLOT]) {
      if (proposedX >= SCROLL_RIGHT_TRIGGER_MIN && proposedX < SCROLL_RIGHT_TRIGGER_MAX) state.viewportXOffset = u8(state.viewportXOffset + 1);
    } else {
      if (proposedX >= SCROLL_LEFT_TRIGGER_MIN && proposedX < SCROLL_LEFT_TRIGGER_MAX) state.viewportXOffset = u8(state.viewportXOffset - 1);
    }
  }

  state.objectSprite[TROGG_SLOT] = motion.sprite;
  state.objectX[TROGG_SLOT] = u8(proposedX);
  state.objectY[TROGG_SLOT] = motion.y;
  if (oldX!==state.objectX[TROGG_SLOT] || oldY!==state.objectY[TROGG_SLOT] || oldSprite!==state.objectSprite[TROGG_SLOT])
    playSoundBlock('move', state.objectY[TROGG_SLOT] >>> 2, 0.12);

  if (scanObjectCollisions(COLLIDE_COLLECTIBLE, TROGG_SLOT)) collectObject(state.collidedObjectSlot);
  if (scanObjectCollisions(COLLIDE_PLAYER_HAZARD, TROGG_SLOT)) markPlayerDead(`collision with ${state.collidedQueueTag}`);

  renderFrame();
  updateInfo();
}

function collectObject(slot) {
  const sprite = state.objectSprite[slot];
  playSoundBlock('collect', null, 0.18);
  if (sprite === FRAK_DATA.constants.SPRITE_KEY) {
    addScoreBCD(0x50);
    state.keysRemainingMinusOne = u8(state.keysRemainingMinusOne - 1);
    if ((state.keysRemainingMinusOne & 0x80) !== 0) beginScreenComplete();
  } else if (sprite === FRAK_DATA.constants.SPRITE_GEM) {
    addScoreBCD(0x15);
  } else if (sprite === FRAK_DATA.constants.SPRITE_BULB) {
    addBcdSeconds(0x10);
  }
  state.objectSprite[slot] = OBJECT_EMPTY;
}

function markPlayerDead(reason) {
  if (state.playerDead) return;
  state.playerDead = true;
  // Original code leaves Trogg's current sprite in place and draws &5B as
  // an additional overlay. &5B is the FRAK! speech bubble composite, not a
  // replacement player frame.
  selectTune('death');
  state.deathTicksRemaining = PLAYER_DEATH_DELAY_TICKS;
  state.levelError = `Trogg died: ${reason}`;
}

// ---------------------------------------------------------------------------
// Dynamic balloons/daggers and PRNG.
// ---------------------------------------------------------------------------

// 6502: RandomUpToA. Browser timer entropy is represented by tickCounter.
function randomUpToA(limit) {
  limit = u8(limit);
  let mask = PRNG_TOP_BIT;
  // The 6502 loop has a deliberate carry escape when a zero limit shifts the
  // probe bit out of bit 0; it then uses a one-bit rejection mask and can return 0.
  while ((mask & limit) === 0) {
    const carry = mask & 1;
    mask >>>= 1;
    if (carry) { mask = 1; break; }
  }
  mask = u8(((mask - 1) << 1) | 1);
  for (;;) {
    state.randomState = u8(state.randomState + PRNG_INCREMENT);
    const candidate = (state.randomState ^ state.tickCounter) & mask;
    if (candidate <= limit) return candidate;
  }
}

function updateDynamicQueue(tag) {
  const q = QUEUES[tag];
  for (let slot = q.first; slot < q.end; slot++) {
    if (state.objectSprite[slot] === OBJECT_EMPTY) continue;
    if (state.objectDX[slot] !== 0) {
      state.objectDX[slot] = u8(state.objectDX[slot] - 1);
      continue;
    }
    if (tag === 'B') {
      const y = state.objectY[slot] + BALLOON_Y_STEP;
      if (y >= BALLOON_DESPAWN_Y) state.objectSprite[slot] = OBJECT_EMPTY;
      else state.objectY[slot] = u8(y);
    } else if (tag === 'D') {
      const y = state.objectY[slot] - DAGGER_Y_STEP;
      if (y < DAGGER_MIN_Y) state.objectSprite[slot] = OBJECT_EMPTY;
      else { state.objectY[slot] = u8(y); state.objectX[slot] = u8(state.objectX[slot] - 1); }
    }
  }
}

// 6502: SpawnHazard (&1BA2)
function spawnHazard() {
  updateDynamicQueue('B');
  updateDynamicQueue('D');
  state.hazardCounter = u8(state.hazardCounter - 1);
  if (state.hazardCounter !== 0) return;
  state.hazardCounter = state.hazardReload;

  const dagger = randomUpToA(HAZARD_RANDOM_MAX) === 0;
  const tag = dagger ? 'D' : 'B';
  const slot = findFreeSlot(tag);
  if (slot < 0) return;
  state.objectSprite[slot] = dagger ? FRAK_DATA.constants.SPRITE_DAGGER : FRAK_DATA.constants.SPRITE_BALLOON;
  state.objectY[slot] = dagger ? DAGGER_SPAWN_Y : BALLOON_SPAWN_Y;
  const span = dagger ? DAGGER_SPAWN_X_SPAN : BALLOON_SPAWN_X_SPAN;
  state.objectX[slot] = u8(randomUpToA(span) + state.viewportXOffset + (dagger ? DAGGER_SPAWN_X_OFFSET : 0));
  state.objectDX[slot] = DYNAMIC_SPAWN_DELAY;
}

// ---------------------------------------------------------------------------
// 50 Hz host: TickIRQ contract + MainGameFrame cadence.
// ---------------------------------------------------------------------------

function decrementCountdownSecond() {
  let seconds = ((state.timeLoBCD >> 4) & 0xf) * 10 + (state.timeLoBCD & 0xf);
  let minutes = ((state.timeHiBCD >> 4) & 0xf) * 10 + (state.timeHiBCD & 0xf);
  if (minutes === 0 && seconds === 0) return;
  if (seconds === 0) { minutes--; seconds = 59; } else seconds--;
  state.timeHiBCD = ((Math.floor(minutes / 10) << 4) | (minutes % 10)) & 0xff;
  state.timeLoBCD = ((Math.floor(seconds / 10) << 4) | (seconds % 10)) & 0xff;
  if (minutes === 0 && seconds === 0 && !state.countdownExpired) {
    state.countdownExpired = true;
    // TimerAndKeys subtracts &0A from HazardReload when the clock first expires.
    state.hazardReload = u8(state.hazardReload - HAZARD_EXPIRED_REDUCTION);
  }
}

// 6502: ScreenComplete (&18CC) and HandleScreenComplete lifecycle, represented
// without BBC VDU text/raster waits. The visible Trogg transition still advances
// one logical X column every four 50 Hz ticks for the original &3C frames.
function beginScreenComplete() {
  if (state.screenCompletePending) return;
  selectTune('complete');
  state.screenCompletePending = true;
  state.completionFramesRemaining = SCREEN_COMPLETE_FRAMES;
  state.completionTickDivider = TRANSITION_FRAME_DELAY;
  state.completionFramePhase = 0;
  state.objectDX[TROGG_SLOT] = 1;
  state.levelError = 'Screen complete — converting remaining time to score.';
}

function addRemainingTimeBonus() {
  // Original HandleScreenComplete repeats the whole MM:SS conversion ten times.
  for (let repeat = 0; repeat < TIME_BONUS_REPEAT_COUNT; repeat++) {
    addScoreBCD(state.timeLoBCD);
    const minutes = ((state.timeHiBCD >> 4) & 0x0f) * 10 + (state.timeHiBCD & 0x0f);
    for (let m = 0; m < minutes; m++) addScoreBCD(BCD_SECONDS_PER_MINUTE);
  }
}

function finishScreenComplete() {
  addRemainingTimeBonus();
  state.baseScreen++;
  if (state.baseScreen >= (FRAK_DATA.constants.BASE_SCREEN_COUNT ?? 3)) {
    state.baseScreen = 0;
    state.transformCycle = (state.transformCycle + 1) & (FRAK_DATA.constants.TRANSFORM_MASK ?? 7);
  }
  startScreen(['A', 'B', 'C'][state.baseScreen]);
}

function screenCompleteTick() {
  if (!state.screenCompletePending) return;
  if (--state.completionTickDivider > 0) return;
  state.completionTickDivider = TRANSITION_FRAME_DELAY;
  state.objectX[TROGG_SLOT] = u8(state.objectX[TROGG_SLOT] + 1);
  state.objectSprite[TROGG_SLOT] = TRANSITION_TROGG_FRAMES[state.completionFramePhase & 3];
  state.completionFramePhase = (state.completionFramePhase + 1) & 3;
  state.completionFramesRemaining--;
  renderFrame();
  updateInfo();
  if (state.completionFramesRemaining <= 0) finishScreenComplete();
}

function parityTick() {
  state.tickCounter = u8(state.tickCounter + 1);
  // MOS ENVELOPE is serviced at 100 Hz; the game tick is 50 Hz.
  mosEnvelopeTick(); mosEnvelopeTick();
  state.musicTickPhase += MUSIC_PHASE_STEP;
  if (state.musicTickPhase >= MUSIC_PHASE_LIMIT) { state.musicTickPhase -= MUSIC_PHASE_LIMIT; soundIRQ(); }

  if (state.mode !== 'playing') { titleTick(); return; }
  if (state.paused) return;
  if (state.yoyoKnockbackTicks > 0) { yoyoKnockbackTick(); return; }

  if (state.playerDead) {
    if (state.deathTicksRemaining > 0) state.deathTicksRemaining--;
    if (state.deathTicksRemaining === 0) {
      state.lives--;
      if (state.lives > 0) startScreen(state.selectedLevel);
      else highScoreInsert();
    }
    return;
  }
  if (!state.running) return;
  if (state.screenCompletePending) { screenCompleteTick(); return; }

  state.countdownDivider--;
  if (state.countdownDivider <= 0) {
    state.countdownDivider = COUNTDOWN_TICKS_PER_SEC;
    decrementCountdownSecond();
  }

  if (u8(state.tickCounter - state.lastPlayerUpdateTick) >= PLAYER_UPDATE_DIVISOR) {
    state.lastPlayerUpdateTick = state.tickCounter;
    updatePlayerFrame();
    spawnHazard();
  }
}

function animationFrame(now) {
  let elapsed = Math.min(250, now - lastFrameTime);
  lastFrameTime = now;
  accumulator += elapsed;
  while (accumulator >= TICK_MS) {
    parityTick();
    accumulator -= TICK_MS;
  }
  requestAnimationFrame(animationFrame);
}

function bcdByteString(v) { return `${(v >> 4) & 15}${v & 15}`; }
function scoreString() { return `${bcdByteString(state.scoreHi)}${bcdByteString(state.scoreMid)}${bcdByteString(state.scoreLo)}0`.replace(/^0+(?=\d)/, ''); }
function timeString() { return `${bcdByteString(state.timeHiBCD)}:${bcdByteString(state.timeLoBCD)}`.replace(/^0(?=\d:)/, ''); }

function updateInfo() {
  document.getElementById('levelValue').textContent = `${state.selectedLevel} / theme ${state.theme}`;
  document.getElementById('transformValue').textContent = state.transformCycle;
  document.getElementById('objectsValue').textContent = Object.keys(QUEUES).map(k => `${k}:${countObjectsOfType(k)}`).join('  ');
  document.getElementById('scoreValue').textContent = scoreString();
  document.getElementById('livesValue').textContent = state.lives;
  const timeNode = document.getElementById('timeValue'); if (timeNode) timeNode.textContent = timeString();
  const playerNode = document.getElementById('playerValue');
  if (playerNode) playerNode.textContent = `x=${state.objectX[0]} y=${state.objectY[0]} dx=${signed8(state.objectDX[0])} dy=${signed8(state.objectDY[0])} ${state.playerClimbing?'climb':state.playerAirborne?'air':'ground'}`;
  let status = state.levelError || 'Stage 4.2: gameplay retained; title/high-score text now uses the BBC MOS 8x8 bitmap font.';
  if (state.mode === 'titleCast') status = 'Original cast/credits entry — SPACE or RETURN starts; timeout enters attract mode.';
  else if (state.mode === 'titleScatter') status = `Attract sequence: ${state.titleRandomDrawCount} random sprite draws remaining.`;
  else if (state.mode === 'titleTransitionLeft') status = `Title transition: Trogg from left (${state.titleTransitionFramesRemaining} frames).`;
  else if (state.mode === 'titleTransitionRight') status = `Title transition: Scrubbly from right (${state.titleTransitionFramesRemaining} frames).`;
  else if (state.mode === 'titleTransitionDelay') status = 'Title transition hold.';
  else if (state.mode === 'titleFinalWait') status = 'Title final Trogg + FRAK! bubble hold.';
  else if (state.mode === 'titleScores') status = 'Grandmaster Frak / high-score screen.';
  else if (state.mode === 'highScoreEntry') status = "High-score entry: Z/X select character; ' commits.";
  else if (state.paused) status = 'Frozen (Delete). Press C to continue.';
  if (state.screenCompletePending) status = `Screen complete: ${state.completionFramesRemaining} transition frames remaining.`;
  status += state.soundMuted ? ' Sound: OFF (S=on).' : ' Sound: ON (Q=off).';
  document.getElementById('status').textContent = status;
}

function selectLevel(letter) { startScreen(letter); }
function setTransform(t) { state.transformCycle = t & 7; applyDisplayTransform(); renderFrame(); updateInfo(); }

for (const b of document.querySelectorAll('[data-level]')) b.addEventListener('click', () => selectLevel(b.dataset.level));
document.getElementById('titleScreen')?.addEventListener('click', () => { ensureAudio(); runtimeGameEntry(); });
document.getElementById('newGame').addEventListener('click', () => { ensureAudio(); newGame(); });
document.getElementById('prevTransform').addEventListener('click', () => setTransform((state.transformCycle + 7) & 7));
document.getElementById('nextTransform').addEventListener('click', () => setTransform((state.transformCycle + 1) & 7));
document.getElementById('soundOn')?.addEventListener('click', () => { ensureAudio(); setSoundMuted(false); });
document.getElementById('soundOff')?.addEventListener('click', () => setSoundMuted(true));
document.getElementById('testScore').addEventListener('click', () => { addScoreBCD(0x50); updateInfo(); });

function normaliseKey(e) {
  if (e.key === 'Enter') return 'enter';
  if (e.key === ' ') return ' ';
  if (e.key.startsWith('Arrow')) return e.key.toLowerCase();
  return e.key.toLowerCase();
}
window.addEventListener('keydown', e => {
  const k = normaliseKey(e);
  ensureAudio();
  if (['z','x',"'",'/','enter',' ','arrowleft','arrowright','arrowup','arrowdown'].includes(k)) e.preventDefault?.();

  if (state.mode === 'highScoreEntry') {
    if (k==='z' || k==='arrowleft') cycleHighScoreChar(-1);
    else if (k==='x' || k==='arrowright') cycleHighScoreChar(1);
    else if (k==="'" || k==='arrowup') commitHighScoreChar();
    return;
  }
  if (state.mode !== 'playing' && (k===' ' || k==='enter')) { startFromTitle(); return; }
  if (k==='q') { setSoundMuted(true); return; }
  if (k==='s') { setSoundMuted(false); return; }
  if (k==='delete' && state.mode==='playing') { state.paused=true; updateInfo(); return; }
  if (k==='c' && state.mode==='playing') { state.paused=false; updateInfo(); return; }
  if (k==='escape' && state.mode==='playing') { gameStartTitleLoop(); return; }

  // Latch short vertical taps until the next 4-tick player sample.  This is a
  // browser-host input buffer, not a change to Frak's jump/climb state machine.
  if (state.mode === 'playing') {
    if (k==="'" || k==='arrowup') state.inputLatchUp = true;
    if (k==='/' || k==='arrowdown') state.inputLatchDown = true;
  }
  pressed.add(k);
  if (e.key >= '1' && e.key <= '3') { state.mode='playing'; state.running=true; selectLevel(['A', 'B', 'C'][Number(e.key) - 1]); }
  if (e.key === '[') setTransform((state.transformCycle + 7) & 7);
  if (e.key === ']') setTransform((state.transformCycle + 1) & 7);
  if (e.key.toLowerCase() === 'r' && state.playerDead) startScreen(state.selectedLevel);
});
window.addEventListener('keyup', e => pressed.delete(normaliseKey(e)));

runtimeGameEntry();
requestAnimationFrame(animationFrame);

window.FRAK = {
  state, newGame, startScreen, loadLevelStream, countObjectsOfType, addScoreBCD,
  drawSpriteAt, renderFrame, spriteTraversal, primitiveBoundsForSprite, collisionScan,
  testFloorCollision, testLadderCollision, testPlayerMove, updatePlayerMotion,
  updateAirbornePlayer, updateClimbingPlayer, updatePlayerFrame, randomUpToA,
  spawnHazard, updateYoyoAttack, continueYoyoAttack, yoyoKnockbackTick, beginScreenComplete, screenCompleteTick, addRemainingTimeBonus, parityTick, pressed,
  runtimeGameEntry, gameStartTitleLoop, titleStartSequence, titleTick, showHighScores, highScoreInsert, cycleHighScoreChar, commitHighScoreChar, renderHighScoreEntry,
  selectTune, musicStep, soundIRQ, setSoundMuted, bbcPitchHz, bbcPitchPeriod,
  playSoundBlock, mosEnvelopeTick, audioDebugState, markPlayerDead, drawBbcGlyph, drawTitleText, BBC_MOS_FONT_8X8, framePixels, renderTitleTransitionScene, formatHighScoreBcd, TITLE_PANEL_RECT
};
